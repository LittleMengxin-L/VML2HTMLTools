$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression

$projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$outputDirectory = Join-Path $projectRoot 'outlook-vml-har/example'
$archivePath = Join-Path $outputDirectory 'VML2HTMLTools-example.zip'
$rootFiles = @('.gitignore', 'README.md', 'LICENSE', 'build-profile.json5', 'code-linter.json5',
  'hvigorfile.ts', 'oh-package.json5', 'oh-package-lock.json5', 'vmlparse.refactored.js')
$sourceDirectories = @('AppScope', 'entry', 'hvigor', 'outlook-vml-har')
$excludedDirectories = @('.git', '.idea', '.hvigor', '.cxx', '.test', 'node_modules',
  'oh_modules', 'build', 'dist', 'example', '.preview', '.cache')
$excludedFiles = @('local.properties', 'audit-fixed-logic.cjs', '.DS_Store', 'Thumbs.db', '.npmrc', '.ohpmrc')
$excludedExtensions = @('.p12', '.pfx', '.p7b', '.cer', '.pem', '.key', '.jks', '.keystore',
  '.log', '.zip', '.har', '.hap', '.hsp', '.7z')

function Get-SourceFiles([string]$directory) {
  foreach ($item in Get-ChildItem -LiteralPath $directory -Force) {
    if ($item.PSIsContainer) {
      if ($excludedDirectories -notcontains $item.Name -and
          -not ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        Get-SourceFiles $item.FullName
      }
    } elseif ($excludedFiles -notcontains $item.Name -and
              $excludedExtensions -notcontains $item.Extension.ToLowerInvariant() -and
              $item.Name -notlike '.env*') {
      $item
    }
  }
}

$files = @(
  foreach ($name in $rootFiles) { Get-Item -LiteralPath (Join-Path $projectRoot $name) }
  foreach ($name in $sourceDirectories) { Get-SourceFiles (Join-Path $projectRoot $name) }
) | Sort-Object FullName

# Check release sources before producing the archive. Diagnostic output contains paths only.
$textExtensions = @('.ets', '.ts', '.js', '.mjs', '.cjs', '.json', '.json5', '.md', '.txt', '.ps1')
foreach ($file in $files) {
  if ($textExtensions -contains $file.Extension -or $file.Name -eq 'LICENSE') {
    $content = [IO.File]::ReadAllText($file.FullName)
    if ($content -match '(?i)[A-Z]:[\\/]+(?:Users|VML)[\\/]' -or
        $content -match '"(?:keyPassword|storePassword|certpath|storeFile|keyAlias)"\s*:' -or
        $content -match '(?i)-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----') {
      throw "Release source contains local or signing data: $($file.FullName)"
    }
  }
}

[IO.Directory]::CreateDirectory($outputDirectory) | Out-Null
$stream = [IO.File]::Open($archivePath, [IO.FileMode]::Create, [IO.FileAccess]::Write)
$archive = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create)
try {
  foreach ($file in $files) {
    $relative = $file.FullName.Substring($projectRoot.Length + 1).Replace('\', '/')
    $entry = $archive.CreateEntry("VML2HTMLTools-example/$relative", [IO.Compression.CompressionLevel]::Optimal)
    $entry.LastWriteTime = [DateTimeOffset]::new(2026, 1, 1, 0, 0, 0, [TimeSpan]::Zero)
    $destination = $entry.Open()
    $source = [IO.File]::OpenRead($file.FullName)
    try { $source.CopyTo($destination) } finally { $source.Dispose(); $destination.Dispose() }
  }
} finally {
  $archive.Dispose()
  $stream.Dispose()
}
Write-Output "Created $archivePath ($($files.Count) source files)"
